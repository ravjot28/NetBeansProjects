package robotscreenshot;

public class Main {

    public static void main(String[] args) {
        Controller c = new Controller();
        c.process();
    }
}

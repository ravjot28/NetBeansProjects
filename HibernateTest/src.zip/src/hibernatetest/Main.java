package hibernatetest;

import DTO.Employee;
import DAO.Process;
import java.util.List;

public class Main {
    
    public static void main(String[] args) {
       Employee emp = new Employee();
       emp.setSapId(1);
       emp.setEmpDOB("26-07-1989");
       emp.setEmpHobbies("Badminton");
       emp.setEmpName("Ravjot Singh");

       Process d = new Process();

       //Save
       d.processSave(emp);

       emp = new Employee();
       emp.setSapId(2);
       emp.setEmpDOB("27-08-1979");
       emp.setEmpHobbies("Reading");
       emp.setEmpName("XYZ");

       d.processSave(emp);

       //Search By ID
       Employee e = d.processSearchByID(1);
       System.out.println(e.getSapId());
       System.out.println(e.getEmpName());
       System.out.println(e.getEmpDOB());
       System.out.println(e.getEmpHobbies());

       //Delete By ID
       d.processDelete(2);

       //Update
       d.processUpdate(1, null, null, "Reading");

       //SearchBy Name
       List l =d.processSearchByName("Ravjot Singh");

       for(Object o:l)
           System.out.println(((Employee)o).getSapId()+"\n"+((Employee)o).getEmpName()+"\n"+((Employee)o).getEmpDOB()+"\n"+((Employee)o).getEmpHobbies());
       
    }

}
